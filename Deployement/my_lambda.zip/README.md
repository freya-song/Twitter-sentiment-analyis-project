# tweets-pre-processing
This is a python library performing preprocessing for a sentiment analysis task with a CNN + Embedding model

## Usage
1. Use `from text_pre_processing.text_pre_processing import PreProcessor` to import the `PreProcessor` class

2. The `PreProcessor` class takes one positional arg `max_length_tweet`, and a kwarg `max_length_dictionary` which has a default value of `400003`.
